// Pruebas de widgets de la Tabla 5 (implementadas) y auditoría de accesibilidad.
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mesa_ayuda/pantalla.dart';
import 'package:mesa_ayuda/solicitudes.dart';

const _una = Solicitud(id: '1', asunto: 'Sin acceso al Wi-Fi', estado: 'abierta');

class _RepoContador implements SolicitudRepository {
  int llamadas = 0;
  @override
  Future<List<Solicitud>> listar() async {
    llamadas++;
    return const [_una];
  }

  @override
  Future<Solicitud> obtener(String id) => throw UnimplementedError();
  @override
  Stream<String> observarEstado(String id) => const Stream.empty();
}

Widget _app(Widget cuerpo, SolicitudRepository repo, {double escala = 1.0}) => MaterialApp(
      theme: ThemeData(useMaterial3: true),
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(escala)),
        child: RepoScope(repo: repo, child: child!),
      ),
      home: Scaffold(body: cuerpo),
    );

SolicitudRepositorySimulado _simulado({Duration? latencia, bool vacio = false}) =>
    SolicitudRepositorySimulado(
      config: SimulacionConfig(
        latencia: latencia ?? const Duration(milliseconds: 10),
        vacio: vacio,
      ),
    );

/// Avanza el reloj simulado y reconstruye.
Future<void> avanzar(WidgetTester t) async {
  await t.pump(const Duration(milliseconds: 50));
  await t.pump();
}

void main() {
  testWidgets('muestra la carga', (tester) async {
    final repo = _simulado(latencia: const Duration(seconds: 1));
    await tester.pumpWidget(_app(SolicitudesPage(repo: repo, onNueva: () {}), repo));
    expect(find.byType(CircularProgressIndicator), findsOneWidget);
    expect(find.bySemanticsLabel('Cargando solicitudes'), findsWidgets);
    // Deja terminar la simulación para no dejar temporizadores pendientes.
    await tester.pump(const Duration(seconds: 2));
    await tester.pump();
  });

  testWidgets('muestra el estado vacío', (tester) async {
    final repo = _simulado(vacio: true);
    await tester.pumpWidget(_app(SolicitudesPage(repo: repo, onNueva: () {}), repo));
    await avanzar(tester);
    expect(find.textContaining('Aún no tienes solicitudes'), findsOneWidget);
    expect(find.text('Nueva solicitud'), findsOneWidget);
    expect(find.text('Reintentar'), findsNothing);
  });

  testWidgets('el fallo conserva visible la lista anterior', (tester) async {
    var reintentos = 0;
    final repo = _RepoContador();
    await tester.pumpWidget(_app(
      VistaFallo(causa: const SinConexion(), previo: const [_una], onReintentar: () => reintentos++),
      repo,
    ));
    expect(find.textContaining('No hay conexión'), findsOneWidget);
    expect(find.text('Sin acceso al Wi-Fi'), findsOneWidget);
    await tester.tap(find.text('Reintentar'));
    expect(reintentos, 1);
  });

  testWidgets('no reinicia la carga al reconstruir el padre', (tester) async {
    final repo = _RepoContador();
    late StateSetter reconstruir;
    await tester.pumpWidget(_app(
      StatefulBuilder(builder: (context, setState) {
        reconstruir = setState;
        return SolicitudesPage(repo: repo, onNueva: () {});
      }),
      repo,
    ));
    await avanzar(tester);
    reconstruir(() {});
    await tester.pump();
    expect(repo.llamadas, 1);
  });

  group('Accesibilidad (texto al 200 %)', () {
    Future<void> auditar(WidgetTester t) async {
      await expectLater(t, meetsGuideline(androidTapTargetGuideline));
      await expectLater(t, meetsGuideline(iOSTapTargetGuideline));
      await expectLater(t, meetsGuideline(labeledTapTargetGuideline));
      await expectLater(t, meetsGuideline(textContrastGuideline));
      expect(t.takeException(), isNull); // sin desbordes
    }

    testWidgets('lista con datos', (tester) async {
      final handle = tester.ensureSemantics();
      final repo = _simulado();
      await tester.pumpWidget(
          _app(SolicitudesPage(repo: repo, onNueva: () {}), repo, escala: 2.0));
      await avanzar(tester);
      await auditar(tester);
      handle.dispose();
    });

    testWidgets('estado de fallo con lista previa', (tester) async {
      final handle = tester.ensureSemantics();
      final repo = _RepoContador();
      await tester.pumpWidget(_app(
        VistaFallo(causa: const TiempoAgotado(), previo: const [_una], onReintentar: () {}),
        repo,
        escala: 2.0,
      ));
      await tester.pump();
      await auditar(tester);
      handle.dispose();
    });

    testWidgets('estado vacío', (tester) async {
      final handle = tester.ensureSemantics();
      final repo = _simulado(vacio: true);
      await tester.pumpWidget(
          _app(SolicitudesPage(repo: repo, onNueva: () {}), repo, escala: 2.0));
      await avanzar(tester);
      await auditar(tester);
      handle.dispose();
    });
  });
}
