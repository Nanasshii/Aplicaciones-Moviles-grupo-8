import 'package:flutter/material.dart';

import 'pantalla.dart';
import 'solicitudes.dart';

void main() {
  // Cambien probabilidadFallo / fallo / vacio para probar cada estado.
  final repo = SolicitudRepositorySimulado(
    config: const SimulacionConfig(probabilidadFallo: 0.4, fallo: TipoFallo.red),
  );
  runApp(MesaAyudaApp(repo: repo));
}

class MesaAyudaApp extends StatelessWidget {
  const MesaAyudaApp({super.key, required this.repo});

  final SolicitudRepository repo;

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Mesa de ayuda',
        theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
        builder: (context, child) => RepoScope(repo: repo, child: child!),
        home: Builder(
          builder: (context) {
            void nueva() => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Pantalla «Nueva solicitud» pendiente.')),
                );
            return Scaffold(
              appBar: AppBar(title: const Text('Mis solicitudes')),
              floatingActionButton: FloatingActionButton(
                tooltip: 'Nueva solicitud',
                onPressed: nueva,
                child: const Icon(Icons.add),
              ),
              body: SolicitudesPage(repo: repo, onNueva: nueva),
            );
          },
        ),
      );
}
