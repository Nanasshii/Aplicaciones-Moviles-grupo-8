// Listados 1 y 2 del informe: modelo, fallos, repositorio abstracto,
// repositorio simulado, estados sealed y controlador. Dart puro (sin Flutter).
import 'dart:async';
import 'dart:math';

// ----------------------------------------------------------------- Listado 1

class Solicitud {
  const Solicitud({required this.id, required this.asunto, required this.estado});

  final String id, asunto, estado; // estado: abierta | en_proceso | resuelta

  factory Solicitud.fromJson(Object? json) {
    if (json is! Map<String, dynamic>) throw const FormatException('Se esperaba un objeto');
    final id = json['id'], asunto = json['asunto'], estado = json['estado'];
    if (id is! String || asunto is! String || estado is! String) {
      throw const FormatException('Campo ausente o con tipo incorrecto');
    }
    return Solicitud(id: id, asunto: asunto, estado: estado);
  }
}

sealed class FalloDatos implements Exception {
  const FalloDatos();
}

final class SinConexion extends FalloDatos {
  const SinConexion();
}

final class TiempoAgotado extends FalloDatos {
  const TiempoAgotado();
}

final class RespuestaInvalida extends FalloDatos {
  const RespuestaInvalida();
}

final class FalloInesperado extends FalloDatos {
  const FalloInesperado();
}

abstract interface class SolicitudRepository {
  Future<List<Solicitud>> listar();
  Future<Solicitud> obtener(String id);
  Stream<String> observarEstado(String id);
}

enum TipoFallo { red, tiempo, malformada }

class SimulacionConfig {
  const SimulacionConfig({
    this.latencia = const Duration(milliseconds: 800),
    this.probabilidadFallo = 0.0,
    this.fallo = TipoFallo.red,
    this.vacio = false,
  });
  final Duration latencia;
  final double probabilidadFallo;
  final TipoFallo fallo;
  final bool vacio;
}

class SolicitudRepositorySimulado implements SolicitudRepository {
  SolicitudRepositorySimulado({this.config = const SimulacionConfig(), Random? azar})
      : _azar = azar ?? Random();

  final SimulacionConfig config;
  final Random _azar;

  static const List<Object?> _datos = [
    {'id': '1', 'asunto': 'Sin acceso al Wi-Fi', 'estado': 'abierta'},
    {'id': '2', 'asunto': 'Error al matricularme', 'estado': 'en_proceso'},
  ];
  static const List<Object?> _corrupto = [
    {'id': 7, 'asunto': null},
  ];

  /// Espera la latencia y decide si la llamada falla.
  /// Devuelve true cuando hay que entregar datos corruptos.
  Future<bool> _simular() async {
    await Future<void>.delayed(config.latencia);
    if (_azar.nextDouble() >= config.probabilidadFallo) return false;
    return switch (config.fallo) {
      TipoFallo.red => throw const SinConexion(),
      TipoFallo.tiempo => throw const TiempoAgotado(),
      TipoFallo.malformada => true,
    };
  }

  @override
  Future<List<Solicitud>> listar() async {
    final malformada = await _simular();
    if (config.vacio) return const [];
    try {
      return [for (final j in (malformada ? _corrupto : _datos)) Solicitud.fromJson(j)];
    } on FormatException {
      throw const RespuestaInvalida();
    }
  }

  @override
  Future<Solicitud> obtener(String id) async => (await listar())
      .firstWhere((s) => s.id == id, orElse: () => throw const RespuestaInvalida());

  @override
  Stream<String> observarEstado(String id) async* {
    for (final e in const ['abierta', 'en_proceso', 'resuelta']) {
      await _simular(); // puede emitir un error en el flujo
      yield e;
    }
  }
}

// ----------------------------------------------------------------- Listado 2

sealed class EstadoPantalla<T> {
  const EstadoPantalla();
}

final class Cargando<T> extends EstadoPantalla<T> {
  const Cargando({this.previo});
  final T? previo;
}

final class ConDatos<T> extends EstadoPantalla<T> {
  const ConDatos(this.datos);
  final T datos;
}

final class Vacio<T> extends EstadoPantalla<T> {
  const Vacio();
}

final class Fallo<T> extends EstadoPantalla<T> {
  const Fallo(this.causa, {this.ultimoDato});
  final FalloDatos causa;
  final T? ultimoDato;
}

typedef EstadoLista = EstadoPantalla<List<Solicitud>>;

class SolicitudesController {
  SolicitudesController(this._repo, {this.limite = const Duration(seconds: 5)});

  final SolicitudRepository _repo;
  final Duration limite;

  // Suscripción única: guarda los eventos en búfer hasta que el StreamBuilder se suscribe.
  final _salida = StreamController<EstadoLista>();
  List<Solicitud>? _ultimoValido;

  Stream<EstadoLista> get estados => _salida.stream;

  Future<void> cargar() async {
    _emitir(Cargando(previo: _ultimoValido));
    try {
      final datos = await _repo.listar().timeout(limite);
      _ultimoValido = datos.isEmpty ? null : datos; // solo se guarda lo válido
      _emitir(datos.isEmpty ? const Vacio() : ConDatos(datos));
    } on TimeoutException {
      _emitir(Fallo(const TiempoAgotado(), ultimoDato: _ultimoValido));
    } on FalloDatos catch (f) {
      _emitir(Fallo(f, ultimoDato: _ultimoValido));
    } catch (_) {
      _emitir(Fallo(const FalloInesperado(), ultimoDato: _ultimoValido));
    }
  }

  void _emitir(EstadoLista e) {
    if (!_salida.isClosed) _salida.add(e);
  }

  Future<void> dispose() => _salida.close();
}
