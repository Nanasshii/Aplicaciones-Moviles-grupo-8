// Listado 4 del informe: pruebas unitarias en Dart puro (solo package:test).
import 'package:mesa_logica/solicitudes.dart';
import 'package:test/test.dart';

class _RepoGuionado implements SolicitudRepository {
  _RepoGuionado(this._respuestas);
  final List<Future<List<Solicitud>> Function()> _respuestas;
  @override
  Future<List<Solicitud>> listar() => _respuestas.removeAt(0)();
  @override
  Future<Solicitud> obtener(String id) => throw UnimplementedError();
  @override
  Stream<String> observarEstado(String id) => const Stream.empty();
}

SolicitudRepositorySimulado _repo(SimulacionConfig c) => SolicitudRepositorySimulado(config: c);

void main() {
  const rapido = Duration.zero;

  test('fromJson rechaza valores mal formados', () {
    expect(() => Solicitud.fromJson(42), throwsFormatException);
    expect(() => Solicitud.fromJson({'id': 7, 'asunto': null}), throwsFormatException);
  });

  group('SolicitudRepositorySimulado', () {
    test('devuelve datos cuando no hay fallos', () async {
      expect(await _repo(const SimulacionConfig(latencia: rapido)).listar(), hasLength(2));
    });
    test('respuesta malformada se traduce a RespuestaInvalida', () {
      final r = _repo(const SimulacionConfig(
          latencia: rapido, probabilidadFallo: 1.0, fallo: TipoFallo.malformada));
      expect(r.listar(), throwsA(isA<RespuestaInvalida>()));
    });
  });

  group('SolicitudesController', () {
    test('éxito: Cargando y luego ConDatos', () async {
      final c = SolicitudesController(_repo(const SimulacionConfig(latencia: rapido)));
      final esperado = expectLater(c.estados, emitsInOrder([isA<Cargando>(), isA<ConDatos>()]));
      await c.cargar();
      await esperado;
    });

    test('un fallo conserva el último dato válido', () async {
      final c = SolicitudesController(_RepoGuionado([
        () async => [const Solicitud(id: '1', asunto: 'Wi-Fi', estado: 'abierta')],
        () async => throw const SinConexion(),
      ]));
      final vistos = <EstadoLista>[];
      c.estados.listen(vistos.add);
      await c.cargar();
      await c.cargar();
      await pumpEventQueue();
      final ultimo = vistos.last as Fallo<List<Solicitud>>;
      expect(ultimo.causa, isA<SinConexion>());
      expect(ultimo.ultimoDato, hasLength(1));
    });

    test('respuesta más lenta que el límite produce TiempoAgotado', () async {
      final c = SolicitudesController(
          _repo(const SimulacionConfig(latencia: Duration(milliseconds: 200))),
          limite: const Duration(milliseconds: 20));
      final vistos = <EstadoLista>[];
      c.estados.listen(vistos.add);
      await c.cargar();
      await pumpEventQueue();
      expect((vistos.last as Fallo).causa, isA<TiempoAgotado>());
    });
  });
}
