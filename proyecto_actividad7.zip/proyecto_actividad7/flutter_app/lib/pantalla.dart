// Listado 3 del informe (pantallas) más las vistas auxiliares que el listado
// no define, con las correcciones de accesibilidad de la Tabla 4.
import 'package:flutter/material.dart';

import 'solicitudes.dart';

/// Gris secundario #616161: contraste 6.19:1 sobre blanco (Tabla 4).
const Color _gris = Color(0xFF616161);

/// Entrega el repositorio a las rutas hijas (se coloca en MaterialApp.builder).
class RepoScope extends InheritedWidget {
  const RepoScope({super.key, required this.repo, required super.child});

  final SolicitudRepository repo;

  static SolicitudRepository of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<RepoScope>();
    assert(scope != null, 'Falta un RepoScope sobre el árbol de widgets');
    return scope!.repo;
  }

  @override
  bool updateShouldNotify(RepoScope oldWidget) => repo != oldWidget.repo;
}

// ------------------------------------------------------------- Listado 3 (a)

class SolicitudesPage extends StatefulWidget {
  const SolicitudesPage({super.key, required this.repo, required this.onNueva});

  final SolicitudRepository repo;
  final VoidCallback onNueva;

  @override
  State<SolicitudesPage> createState() => _SolicitudesPageState();
}

class _SolicitudesPageState extends State<SolicitudesPage> {
  late final SolicitudesController _ctrl;
  late final Stream<EstadoLista> _estados;

  @override
  void initState() {
    super.initState();
    _ctrl = SolicitudesController(widget.repo);
    _estados = _ctrl.estados; // el Stream se crea una sola vez
    _ctrl.cargar();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<EstadoLista>(
        stream: _estados,
        initialData: const Cargando(),
        builder: (context, snap) => switch (snap.requireData) { // switch exhaustivo
          Cargando(:final previo) => VistaCarga(previo: previo),
          ConDatos(:final datos) => ListaSolicitudes(datos),
          Vacio() => VistaVacia(onNueva: widget.onNueva),
          Fallo(:final causa, :final ultimoDato) =>
            VistaFallo(causa: causa, previo: ultimoDato, onReintentar: _ctrl.cargar),
        },
      );
}

// ------------------------------------------------------------- Listado 3 (b)

class DetallePage extends StatefulWidget {
  const DetallePage({super.key, required this.repo, required this.id});

  final SolicitudRepository repo;
  final String id;

  @override
  State<DetallePage> createState() => _DetalleState();
}

class _DetalleState extends State<DetallePage> {
  late Future<Solicitud> _detalle;
  late final Stream<String> _estado;

  @override
  void initState() {
    super.initState();
    _detalle = widget.repo.obtener(widget.id);
    _estado = widget.repo.observarEstado(widget.id);
  }

  void _reintentar() => setState(() => _detalle = widget.repo.obtener(widget.id));

  @override
  Widget build(BuildContext context) => FutureBuilder<Solicitud>(
        future: _detalle,
        builder: (context, snap) => snap.hasError
            ? VistaFallo(causa: snap.error, onReintentar: _reintentar)
            : !snap.hasData
                ? const VistaCarga()
                : DetalleSolicitud(snap.requireData, estado: _estado),
      );
}

// ------------------------------------------------------------------- Vistas

class VistaCarga extends StatelessWidget {
  const VistaCarga({super.key, this.previo});

  final List<Solicitud>? previo;

  @override
  Widget build(BuildContext context) {
    final indicador = Semantics(
      liveRegion: true,
      label: 'Cargando solicitudes',
      child: const Padding(
        padding: EdgeInsets.all(16),
        child: Center(child: CircularProgressIndicator()),
      ),
    );
    final p = previo;
    if (p == null) return Center(child: indicador);
    return Column(children: [indicador, Expanded(child: ListaSolicitudes(p))]);
  }
}

class VistaVacia extends StatelessWidget {
  const VistaVacia({super.key, required this.onNueva});

  final VoidCallback onNueva;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const ExcludeSemantics(child: Icon(Icons.inbox_outlined, size: 64, color: _gris)),
              const SizedBox(height: 12),
              const Text(
                'Aún no tienes solicitudes. Cuando registres una, aparecerá aquí.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: onNueva,
                icon: const Icon(Icons.add),
                label: const Text('Nueva solicitud'),
                style: FilledButton.styleFrom(minimumSize: const Size(48, 48)),
              ),
            ],
          ),
        ),
      );
}

class VistaFallo extends StatelessWidget {
  const VistaFallo({
    super.key,
    required this.causa,
    required this.onReintentar,
    this.previo,
  });

  /// Puede ser un [FalloDatos] o cualquier otro objeto (p. ej. snap.error).
  final Object? causa;
  final List<Solicitud>? previo;
  final VoidCallback onReintentar;

  @override
  Widget build(BuildContext context) {
    final c = causa;
    final FalloDatos fallo = c is FalloDatos ? c : const FalloInesperado();
    final mensaje = switch (fallo) {
      SinConexion() => 'No hay conexión. Revisa tu red e inténtalo de nuevo.',
      TiempoAgotado() => 'El servidor tardó demasiado en responder.',
      RespuestaInvalida() => 'Recibimos datos incorrectos del servidor.',
      FalloInesperado() => 'Ocurrió un error inesperado. Inténtalo de nuevo.',
    };
    final p = previo;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Semantics(
                liveRegion: true,
                child: Text(mensaje, textAlign: TextAlign.center),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: onReintentar,
                icon: const Icon(Icons.refresh),
                label: const Text('Reintentar'),
                style: FilledButton.styleFrom(minimumSize: const Size(48, 48)),
              ),
            ],
          ),
        ),
        if (p != null) Expanded(child: ListaSolicitudes(p)),
      ],
    );
  }
}

class ListaSolicitudes extends StatelessWidget {
  const ListaSolicitudes(this.datos, {super.key});

  final List<Solicitud> datos;

  @override
  Widget build(BuildContext context) => ListView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: datos.length,
        itemBuilder: (context, i) {
          final s = datos[i];
          return Card(
            child: ListTile(
              title: Text(s.asunto),
              subtitle: EstadoEtiqueta(s.estado),
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => Scaffold(
                  appBar: AppBar(title: const Text('Detalle de la solicitud')),
                  body: DetallePage(repo: RepoScope.of(context), id: s.id),
                ),
              )),
            ),
          );
        },
      );
}

class DetalleSolicitud extends StatelessWidget {
  const DetalleSolicitud(this.solicitud, {super.key, required this.estado});

  final Solicitud solicitud;
  final Stream<String> estado;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(solicitud.asunto, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            StreamBuilder<String>(
              stream: estado,
              initialData: solicitud.estado,
              builder: (context, snap) => snap.hasError
                  ? const Text(
                      'El estado de atención no está disponible ahora.',
                      style: TextStyle(color: _gris),
                    )
                  : EstadoEtiqueta(snap.requireData),
            ),
          ],
        ),
      );
}

/// Estado con icono Y texto: no depende solo del color (Tabla 4).
class EstadoEtiqueta extends StatelessWidget {
  const EstadoEtiqueta(this.estado, {super.key});

  final String estado;

  @override
  Widget build(BuildContext context) {
    final (etiqueta, icono) = switch (estado) {
      'abierta' => ('Abierta', Icons.radio_button_unchecked),
      'en_proceso' => ('En proceso', Icons.timelapse),
      'resuelta' => ('Resuelta', Icons.check_circle_outline),
      _ => (estado, Icons.help_outline),
    };
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        ExcludeSemantics(child: Icon(icono, size: 18, color: _gris)),
        const SizedBox(width: 6),
        Flexible(child: Text('Estado: $etiqueta', style: const TextStyle(color: _gris))),
      ],
    );
  }
}
